from django.db import models
import string
import random
from django.utils import timezone
from django.contrib.auth.models import User

def unique_id():
    return "".join(random.choices(string.ascii_letters + string.digits, k=20))

# Create your models here.
class Register_Model(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=100)
    password_confirm = models.CharField(max_length=100)

    def __str__ (self):
        return self.email

#product category  
class Category(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='image')
    slug = models.SlugField(unique=True)

    def __str__ (self):
        return self.title
    
    class Meta:
        verbose_name_plural = "categories"
        ordering = ['title']

#products

class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    status = models.CharField(max_length=100, default='published')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField(default=0)
    image = models.ImageField(upload_to='image')
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True)
    description = models.TextField(max_length=1000, default='No description provided')
    date = models.DateField(default=timezone.now)

    def __str__ (self):
        return self.name
    
    class Meta:
        verbose_name_plural = "products"

class Variant(models.Model):
    product = models.ForeignKey(Product, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=100)
    def __str__ (self):
        return self.name
    
class VariantItem(models.Model):
    variant = models.ForeignKey(Variant, null=True, on_delete=models.SET_NULL)
    title = models.CharField(verbose_name="Item Title" ,max_length=1000)
    content = models.CharField(verbose_name="Item Content", max_length=1000)

    def __str__ (self):
        return self.title
    
class Coupon(models.Model):
    vendor = models.ForeignKey("auth.user", on_delete=models.SET_NULL, null=True)
    code = models.CharField(max_length=50, unique=True)
    discount = models.IntegerField(default=1)

    def __str__ (self):
        return self.code

class Order(models.Model):
    vendor = models.ManyToManyField('auth.User', blank=True, related_name='orders')
    customer = models.ForeignKey('auth.User', null=True, on_delete=models.SET_NULL, related_name='customer_orders')
    order_id = models.CharField(unique=True, default=unique_id, max_length=100)
    payment_status = models.CharField(max_length=100, default="Processing")
    payment_method = models.CharField(max_length=100, default="None")
    order_status = models.CharField(max_length=100, default="Processing")
    coupon = models.ForeignKey(Coupon, null=True, on_delete=models.SET_NULL)
    payment_id = models.CharField(max_length=50, blank=True)
    date = models.DateTimeField(default=timezone.now)


    class Meta:
        verbose_name_plural = "Orders"
        ordering = ['date']

    def __str__ (self):
        return self.order_id
    
    def order_items(self):
        return OrderItem.objects.filter(order = self)

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    order_status = models.CharField(default='Pending', max_length=100)
    shipping_services = models.CharField(max_length=100, default='None')
    tracking_id = models.CharField(max_length=100, unique=True, default=unique_id)
    product = models.ForeignKey(Product,  on_delete=models.SET_NULL, null=True )
    vendor = models.ForeignKey('auth.User',  on_delete=models.SET_NULL, null=True , related_name='vendor_orders')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField()
    total_products = models.IntegerField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__ (self):
        return self.tracking_id



RATTING = (
    (1, '★'),
    (2, '★★'),
    (3, '★★★'),
    (4, '★★★★'),
    (5, '★★★★★')
)

class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True ,blank=True)
    Product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    reply = models.TextField(null=True, blank=True)
    ratting = models.IntegerField(choices=RATTING)

    def __str__ (self):
        return self.user

class Gallery(models.Model):
    product = models.ForeignKey(Product, null=True, on_delete=models.SET_NULL)
    title = models.FileField(verbose_name='imae', default='gallery.jpg')
    content = models.CharField(unique=True, max_length=100, default=unique_id )

    def __str__ (self):
        return self.product


class MyCart(models.Model):
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField(default=1)  # Ensure a default quantity
    total_products = models.IntegerField(default=1)  # ✅ Set a default value
    date = models.DateTimeField(auto_now_add=True)
    cart_id = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    shipping = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # ✅ Add a default value

    def save(self, *args, **kwargs):
        self.total_products = self.quantity  # Ensure total_products is updated
        super(MyCart, self).save(*args, **kwargs)

    def __str__(self):
        return f'{self.cart_id} - {self.product.name}'
