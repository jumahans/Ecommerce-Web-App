from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.login_view, name='login'),
    path('register/', views.register_view, name="register"),
    path('home/', views.home_view, name='home'),  # Default home route
    path('home/<slug:category_slug>/', views.home_view, name='home_by_category'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.update_profile_view, name='profile'),
    path('category/<str:title>/', views.category_view, name='category'),
    path('cart/', views.cart_view, name='cart'),
     path("cart/remove/<int:item_id>/", views.remove_from_cart, name="remove_from_cart"), 
    path('product/<int:pk>/', views.product_detail_view, name='product'),
     path("checkout/", views.checkout, name="checkout"),
    path('cart/add/<int:product_id>/', views.create_cart_item, name='add_to_cart'),
    # path('cart/update/<str:cart_id>/', views.update_cart_view, name='update_cart'),
    # path('cart/delete/<str:cart_id>/', views.delete_cart_item, name='delete_cart'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
