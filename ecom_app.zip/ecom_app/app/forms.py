from django import forms
from .models import Register_Model, MyCart

class Register_Form(forms.ModelForm):
    username = forms.CharField(max_length=100, widget=forms.TextInput(attrs={
        'class':"forms-controlls"
    }))
    email = forms.EmailField(widget=forms.EmailInput(attrs={
        'class':"forms-controlls"
    }))
    password = forms.CharField(max_length=100, widget=forms.PasswordInput(attrs={
        'class':"forms-controlls"
    }))
    password_confirm = forms.CharField(max_length=100, widget=forms.PasswordInput(attrs={
        'class':"forms-controlls"
    }))

    class Meta:
        model = Register_Model
        fields = "__all__"
    
    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get('username')
        email = cleaned_data.get('email')
        password = cleaned_data.get('password')
        password_confirm = cleaned_data.get('password_confirm')

        if password_confirm != password:
            self.add_error('password_confirm', "Password does not match")

        else:
            return cleaned_data

class MyCartForm(forms.ModelForm):
    class Meta:
        model = MyCart
        fields = ['product', 'quantity', 'shipping']  # Include only necessary fields
